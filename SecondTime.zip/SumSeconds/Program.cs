﻿using System;

namespace SumSeconds
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int seconds1 = int.Parse(Console.ReadLine());
            int seconds2 = int.Parse(Console.ReadLine());
            int seconds3 = int.Parse(Console.ReadLine());

            int totalSeconds = seconds1 + seconds2 + seconds3;
            int minutes = totalSeconds / 60;
            int remainingSeconds = totalSeconds % 60;

            if (remainingSeconds >= 10)
            {
                Console.WriteLine($"{minutes}:{remainingSeconds}");
            }
            else
            {
                Console.WriteLine($"{minutes}:0{remainingSeconds}");
            }
        }
    }
}