﻿int h = int.Parse(Console.ReadLine());
int l = int.Parse(Console.ReadLine());

string command = Console.ReadLine();
int cake = h * l;
while(command != "STOP")
{
    int piece = int.Parse(command);
    if(cake >= piece)
    {
        cake -= piece;
    }
    else
    {
         Console.WriteLine($"No more cake left! You need {piece-cake} pieces more.");
        cake = 0;
        break;
    }
    command = Console.ReadLine();
}
if(cake > 0)
{
    Console.WriteLine($"{cake} pieces are left.");
}