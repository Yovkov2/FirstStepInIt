﻿string hersBook = Console.ReadLine();
int count = 0;

string book = Console.ReadLine();
while(book != "No More Books")
{
    
    if(book == hersBook)
    {
        break;
    }
    book = Console.ReadLine();
    count++;
}
if(book == hersBook)
{
    Console.WriteLine($"You checked {count} books and found it.");
}
else
{
    Console.WriteLine($"The book you search is not here!");
    Console.WriteLine($"You checked {count} books");
}