﻿double neededMoney = double.Parse(Console.ReadLine());
double moneyNow = double.Parse(Console.ReadLine());
int daysSpends = 0;
int count = 0;

while(neededMoney > moneyNow && daysSpends < 5)
{
    string command = Console.ReadLine();
    int money = int.Parse(Console.ReadLine());
    count++;
    if(command == "spend")
    {
        if(moneyNow < money)
        {
            moneyNow = 0;
        }
        else
        {
            moneyNow -= money;
            daysSpends++;
        }
    }
    else if(command == "save")
    {
        moneyNow += money;
        daysSpends = 0;
    }
}
if(moneyNow >= neededMoney)
{
    Console.WriteLine($"You saved the money for {count} days.");
}
else if(daysSpends == 5)
{
    Console.WriteLine("You can't save the money.");
    Console.WriteLine($"{count}");
}
