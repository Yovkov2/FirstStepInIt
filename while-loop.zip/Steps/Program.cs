﻿string command = Console.ReadLine();
int goals = 10000;
int sum = 0;

while (command != "Going home")
{
    int steps = int.Parse(command);
    sum += steps;
    if(sum >= goals)
    {
        break;
    }
    command = Console.ReadLine();
}
if(sum >= goals)
{
    Console.WriteLine($"Goal reached! Good job!");
    Console.WriteLine($"{sum - goals} steps over the goal!");
}
else if(command == "Going home")
{
    int steps = int.Parse(Console.ReadLine());
    sum += steps;
    if(sum < goals)
    {
        Console.WriteLine($"{goals-sum} more steps to reach goal.");
    }
    else
    {
        Console.WriteLine($"Goal reached! Good job!");
        Console.WriteLine($"{sum - goals} steps over the goal!");
    }
}