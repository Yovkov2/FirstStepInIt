﻿int badGrade = int.Parse(Console.ReadLine());
string command = Console.ReadLine();
double count = 0;
double sum = 0;
string last = string.Empty;
int bad = 0;
while (command != "Enough")
{
    double grade = double.Parse(Console.ReadLine());
    if( command == "Enough")
    {
        break;
    }
    if(grade <= 4)
    {
        bad++;
        if(bad >= badGrade)
        {
            Console.WriteLine($"You need a break, {bad} poor grades.");
            return;
        }
    }
    sum += grade;
    last = command;
    count++;
    command = Console.ReadLine();
}
if(command == "Enough")
{
    Console.WriteLine($"Average score: {sum / count:f2}");
    Console.WriteLine($"Number of problems: {count}");
    Console.WriteLine($"Last problem: {last}");
}