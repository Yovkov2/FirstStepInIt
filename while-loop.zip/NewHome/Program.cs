﻿int w = int.Parse(Console.ReadLine());
int l = int.Parse(Console.ReadLine());
int h = int.Parse(Console.ReadLine());
string commmand = Console.ReadLine();
int allPlace = w * l * h;
while(commmand != "Done")
{
    int numberBox = int.Parse(commmand);
    if(allPlace >= numberBox)
    {
        allPlace -= numberBox;
    }
    else
    {
        Console.WriteLine($"No more free space! You need {numberBox-allPlace} Cubic meters more.");
        break;
    }
    commmand = Console.ReadLine();
}
if(allPlace > 0)
{
    Console.WriteLine($"{allPlace} Cubic meters left.");
}