﻿int people = int.Parse(Console.ReadLine());

string taskName = Console.ReadLine();

double presentationEv;
int presentationCount = 0;
double presentationAvg = 0;

while (taskName != "Finish") 
{
    presentationCount++;
    presentationEv = 0;

    for (int i = 0; i < people; i++)
    {
        presentationEv += double.Parse(Console.ReadLine());
    }
    presentationEv /= people;
    presentationAvg += presentationEv;

    Console.WriteLine($"{taskName} - {presentationEv:f2}.");

    taskName = Console.ReadLine();
}
presentationAvg /= presentationCount;
Console.WriteLine($"Student's final assessment is {presentationAvg:f2}.");
