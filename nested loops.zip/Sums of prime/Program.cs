﻿string command = Console.ReadLine();
int even = 0;
int odd = 0;    
while(command != "stop")
{
    int number = int.Parse(command);
    if(number < 0)
    {
        Console.WriteLine("Number is negative.");
        command = Console.ReadLine();
        continue;
    }
    bool isPrime = true;
    for(int i = 2; i < number; i++)
    {
        if(number % i == 0)
        {
            isPrime = false;
            break;
        }
    }
    if(isPrime == true)
    {
        even += number;
    }
    else
    {
        odd += number;
    }
    command = Console.ReadLine();
}
Console.WriteLine($"Sum of all prime numbers is: {even}");
Console.WriteLine($"Sum of all non prime numbers is: {odd}");