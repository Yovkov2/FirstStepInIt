﻿int studentTickets = 0;
int standardTickets = 0;
int kidTickets = 0;

string filmName = Console.ReadLine();

while(filmName != "Finish")
{
    int empty = int.Parse(Console.ReadLine());

    string type = Console.ReadLine();

    int nowFilm = 0;

    while(type != "End")
    {
        if(type == "student")
        {
            studentTickets++;
        }
        else if(type == "standard")
        {
            standardTickets++;
        }
        else
        {
            kidTickets++;
        }
        nowFilm++;
        if(nowFilm == empty)
        {
            break;
        }
        type = Console.ReadLine();
    }
    double occupancy = nowFilm * 100.0 / empty;
    Console.WriteLine($"{filmName} - {occupancy:f2}% full.");
    filmName = Console.ReadLine();
}
int totalTickets = studentTickets + standardTickets + kidTickets;
Console.WriteLine($"Total tickets: {totalTickets}");

Console.WriteLine($"{studentTickets * 100.0 / totalTickets:f2}% student tickets.");
Console.WriteLine($"{standardTickets * 100.0 / totalTickets:f2}% standard tickets.");
Console.WriteLine($"{kidTickets * 100.0 / totalTickets:f2}% kids tickets.");