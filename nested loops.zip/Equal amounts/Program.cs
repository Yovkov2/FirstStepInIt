﻿int n1 = int.Parse(Console.ReadLine());
int n2 = int.Parse(Console.ReadLine());

for (int i = n1; i <= n2; i++)
{
    int oddsum = 0;
    int even = 0;
    string curent = i.ToString();
    for (int j = 0; j < curent.Length; j++)
    {
        if (j % 2 == 0)
        {
            even += curent[j];
        }
        else
        {
            oddsum += curent[j];
        }

    }
    if (even == oddsum)
    {
        Console.Write(curent + " ");
    }
}