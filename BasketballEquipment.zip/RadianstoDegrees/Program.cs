﻿using System;

namespace RadianstoDegrees
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double radiansInput = double.Parse(Console.ReadLine());

            double degreesOutput = radiansInput * 180 / Math.PI;

            Console.WriteLine(degreesOutput);
        }
    }
}