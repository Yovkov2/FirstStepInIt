﻿using System;

namespace SuppliesforSchool
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int numberOfPens = int.Parse(Console.ReadLine());
            int numberOfMarkers = int.Parse(Console.ReadLine());
            int numberOfDusks = int.Parse(Console.ReadLine());
            int discountPercentage = int.Parse(Console.ReadLine());

            double pricePerPen = numberOfPens * 5.80;
            double pricePerMarker = numberOfMarkers * 7.20;
            double pricePerDusk = numberOfDusks * 1.20;

            double totalItemsPrice = pricePerPen + pricePerMarker + pricePerDusk;
            double discountRate = discountPercentage / 100.0;

            double discountedPrice = totalItemsPrice - (totalItemsPrice * discountRate);

            Console.WriteLine(discountedPrice);
        }
    }
}