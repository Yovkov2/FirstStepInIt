﻿using System;

namespace VacationBooksList
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int pagesRead = int.Parse(Console.ReadLine());
            int hoursPerDay = int.Parse(Console.ReadLine());
            int days = int.Parse(Console.ReadLine());

            int pagesPerHour = pagesRead / hoursPerDay;
            int pagesPerDay = pagesPerHour / days;
            Console.WriteLine(pagesPerDay);
        }
    }
}