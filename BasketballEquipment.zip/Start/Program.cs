﻿using System;

namespace CurrencyConverter
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double usdAmount = double.Parse(Console.ReadLine());

            double bgnAmount = usdAmount * 1.79549;

            Console.WriteLine(bgnAmount);
        }
    }
}