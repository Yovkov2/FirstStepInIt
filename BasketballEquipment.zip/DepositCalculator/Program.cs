﻿using System;

namespace DepositCalculator
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double initialAmount = double.Parse(Console.ReadLine());
            int months = int.Parse(Console.ReadLine());
            double interestRate = double.Parse(Console.ReadLine());

            double interestAmount = initialAmount * interestRate / 100;
            double monthlyInterest = (interestAmount / 12);
            double finalAmount = initialAmount + months * monthlyInterest;
            Console.WriteLine(finalAmount);
        }
    }
}